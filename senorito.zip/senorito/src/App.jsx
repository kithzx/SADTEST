import { useState } from 'react';
import Sidebar from './components/Sidebar';
import Login from './components/Login';
import OrderScreen from './components/OrderScreen';
import SalesScreen from './components/SalesScreen';
import InventoryScreen from './components/InventoryScreen';
import SettingsScreen from './components/SettingsScreen';
import ClockScreen from './components/ClockScreen';
import './App.css';

const MENU_ITEMS = [
  { id: 'lechon-manok', name: 'Lechon Manok', price: 320, stock: 75 },
  { id: 'liempo',       name: 'Liempo',       price: 350, stock: 3  },
];

export default function App() {
  const [loggedIn, setLoggedIn] = useState(false);
  const [screen, setScreen] = useState('order');
  const [cart, setCart] = useState([]);

  if (!loggedIn) return <Login onLogin={() => setLoggedIn(true)} />;

  return (
    <div className="app">
      <Sidebar
        screen={screen}
        setScreen={setScreen}
        onLogout={() => { setLoggedIn(false); setScreen('order'); setCart([]); }}
      />
      {screen === 'order'     && <OrderScreen menuItems={MENU_ITEMS} cart={cart} setCart={setCart} />}
      {screen === 'sales'     && <SalesScreen />}
      {screen === 'inventory' && <InventoryScreen menuItems={MENU_ITEMS} />}
      {screen === 'settings'  && <SettingsScreen />}
      {screen === 'clock'     && <ClockScreen setScreen={setScreen} />}
    </div>
  );
}