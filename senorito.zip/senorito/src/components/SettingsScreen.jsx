import { useState } from 'react';

export default function SettingsScreen() {
  const [saved, setSaved] = useState(false);

  const handleSave = () => {
    setSaved(true);
    setTimeout(() => setSaved(false), 2500);
  };

  return (
    <main className="main">
      <div className="topbar"><h1>Settings</h1></div>

      <div className="content">
        <div className="settings-nav">
          <div className="profile-mini">
            <div className="avatar">S1</div>
            <div>
              <strong style={{ fontSize: 13 }}>Staff 1</strong>
              <div style={{ fontSize: 11, color: '#999' }}>Cashier · Pullian Branch</div>
            </div>
          </div>
          <div className="nav-item active">👤 My Profile</div>
        </div>

        <div className="settings-panel">
          <h2>My Profile</h2>
          <div className="form-grid">
            <div><label>Full Name</label><input defaultValue="Staff 1" /></div>
            <div><label>Mobile Number</label><input defaultValue="+63 912 345 6789" /></div>
            <div><label>Staff ID</label><input defaultValue="STF-2024-0042" disabled /></div>
            <div><label>Branch</label><input defaultValue="Pullian Branch" disabled /></div>
            <div className="full"><label>Role</label><input defaultValue="Cashier" disabled /></div>
          </div>
          <div className="form-actions">
            <button className="save" onClick={handleSave}>Save Changes</button>
            <button className="cancel">Cancel</button>
          </div>
        </div>
      </div>

      {saved && (
        <div className="toast">
          <div className="dot">✓</div>
          Profile updated.
        </div>
      )}
    </main>
  );
}