export default function CurrentOrder({ cart, updateQty, removeItem }) {
  return (
    <div className="current-order">
      <h2>🛒 Current Order</h2>
      {cart.length === 0 ? (
        <div className="empty-state">
          <div className="empty-icon">🛒</div>
          <strong>Your order is empty</strong>
          <p>Tap a product below to add it to the order.</p>
        </div>
      ) : (
        cart.map((item) => (
          <div key={item.id} className="order-line">
            <div>
              <div className="name">{item.name}</div>
              <div className="sub">₱{item.price.toFixed(2)} each</div>
            </div>
            <div className="qty">
              <button onClick={() => updateQty(item.id, -1)}>−</button>
              <span>{item.qty}</span>
              <button onClick={() => updateQty(item.id, +1)}>+</button>
            </div>
            <div className="price">₱{(item.price * item.qty).toFixed(2)}</div>
            <button className="remove" onClick={() => removeItem(item.id)}>✕</button>
          </div>
        ))
      )}
    </div>
  );
}