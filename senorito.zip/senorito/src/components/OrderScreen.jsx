import CurrentOrder from './CurrentOrder';
import ProductGrid from './ProductGrid';
import OrderSummary from './OrderSummary';

export default function OrderScreen({ menuItems, cart, setCart }) {
  const addToCart = (item) => {
    setCart((prev) => {
      const existing = prev.find((c) => c.id === item.id);
      if (existing) return prev.map((c) => c.id === item.id ? { ...c, qty: c.qty + 1 } : c);
      return [...prev, { ...item, qty: 1 }];
    });
  };

  const updateQty = (id, delta) =>
    setCart((prev) => prev.map((c) => c.id === id ? { ...c, qty: c.qty + delta } : c).filter((c) => c.qty > 0));

  const removeItem = (id) => setCart((prev) => prev.filter((c) => c.id !== id));
  const total = cart.reduce((s, c) => s + c.price * c.qty, 0);

  return (
    <main className="main">
      <div className="topbar">
        <h1>Order</h1>
        <input className="search" placeholder="🔍  Search Product" />
      </div>

      <div className="content">
        <div className="center-col">
          <CurrentOrder cart={cart} updateQty={updateQty} removeItem={removeItem} />
          <ProductGrid menuItems={menuItems} addToCart={addToCart} />
        </div>
        <OrderSummary cart={cart} total={total} clearCart={() => setCart([])} />
      </div>
    </main>
  );
}