import { useState } from 'react';
import logo from '../assets/senorito.png';

export default function Login({ onLogin }) {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');

  const handle = () => {
    if (!username || !password) { setError('Please fill in all fields'); return; }
    if (username === 'staff1' && password === 'senorito123') {
      setError(''); onLogin();
    } else {
      setError('Incorrect username or password. Please try again.');
    }
  };

  return (
    <div className="app">
      <main className="main">
        <div className="login-wrap">
          <div className="login-card">
            <div className="logo">
                <img src={logo} alt="Señiorito" />
            </div>
            <input
              placeholder="👤  Username"
              value={username}
              onChange={(e) => { setUsername(e.target.value); setError(''); }}
              className={error ? 'error' : ''}
            />
            <input
              placeholder="🔒  Password"
              type="password"
              value={password}
              onChange={(e) => { setPassword(e.target.value); setError(''); }}
              className={error ? 'error' : ''}
            />
            {error && <div className="login-error">{error}</div>}
            <button onClick={handle}>Login</button>
          </div>
        </div>
      </main>
    </div>
  );
}