import { useState } from 'react';
import Modal from './Modal';

export default function InventoryScreen({ menuItems }) {
  const [receivedOpen, setReceivedOpen] = useState(false);
  const [reminderSent, setReminderSent] = useState(false);
  const [qty, setQty] = useState(20);

  return (
    <main className="main">
      <div className="topbar">
        <h1>Inventory</h1>
        <input className="search" placeholder="🔍  Search Product" />
      </div>

      <div className="content">
        <div className="inv-table">
          <div className="inv-head">
            <span>Product</span><span>Price</span><span>Stock</span><span>Status</span><span>Last Updated</span>
          </div>
          {menuItems.map((item) => {
            const stock = item.stock ?? 0;
            const low = stock < 5;
            return (
              <div key={item.id} className="inv-row">
                <span>🍗 {item.name}</span>
                <span>₱{item.price.toFixed(2)}</span>
                <span>{stock}</span>
                <span><span className={`badge ${low ? 'low' : 'ok'}`}>{low ? 'Low Stock' : 'In Stock'}</span></span>
                <span style={{ color: '#999' }}>August 1</span>
              </div>
            );
          })}
        </div>

        <div className="delivery-card">
          <h2 style={{ color: '#6B1A1A', marginBottom: 6 }}>Next Delivery</h2>
          <div className="delivery-date">
            <div className="big">August 15</div>
            <div style={{ fontSize: 12, opacity: 0.8 }}>+ 1 item</div>
          </div>
          <button className="btn-primary" onClick={() => setReminderSent(true)}>Remind Request</button>
          <button className="btn-secondary" onClick={() => setReceivedOpen(true)}>Received Delivery</button>
        </div>
      </div>

      {reminderSent && (
        <div className="toast" onClick={() => setReminderSent(false)}>
          <div className="dot">✓</div>
          Reminder sent for the August 15 delivery
        </div>
      )}

      {receivedOpen && (
        <Modal onClose={() => setReceivedOpen(false)}>
          <div className="modal-icon">📦</div>
          <div className="modal-title">Confirm delivery</div>
          <div className="modal-sub">Expected August 15</div>
          <div className="modal-row">
            <span>Liempo (current stock: 3)</span>
            <div className="qty">
              <button onClick={() => setQty(Math.max(1, qty - 1))}>−</button>
              <span>{qty}</span>
              <button onClick={() => setQty(qty + 1)}>+</button>
            </div>
          </div>
          <div className="modal-row"><span>New stock after delivery</span><span>{3 + qty}</span></div>
          <div className="modal-actions">
            <button className="secondary" onClick={() => setReceivedOpen(false)}>Cancel</button>
            <button className="primary" onClick={() => { setReceivedOpen(false); setReminderSent(true); }}>Confirm Received</button>
          </div>
        </Modal>
      )}
    </main>
  );
}