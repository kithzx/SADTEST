import { useState } from 'react';
import Modal from './Modal';

// Sample data for each view
const DATA = {
  hour: {
    labels: ['9AM','10AM','11AM','12PM','1PM','2PM','3PM','4PM','5PM','6PM','7PM','8PM'],
    values: [0, 0, 0, 320, 0, 0, 0, 0, 0, 0, 0, 0],
    max: 320,
    title: 'Sales by Hour · Pullian',
  },
  day: {
    labels: ['Mon','Tue','Wed','Thu','Fri','Sat','Sun'],
    values: [1240, 980, 1520, 1100, 1750, 2100, 1680],
    max: 2200,
    title: 'Sales by Day · This Week',
  },
  week: {
    labels: ['W1','W2','W3','W4'],
    values: [6200, 7400, 5900, 8100],
    max: 9000,
    title: 'Sales by Week · This Month',
  },
};

export default function SalesScreen() {
  const [view, setView] = useState('hour'); // hour | day | week
  const [openTx, setOpenTx] = useState(null);

  const current = DATA[view];

  const kpis = [
    { title: 'Sales', value: '₱320.00', sub: 'Today, Aug 10' },
    { title: 'Transactions', value: '23', sub: 'Total Orders' },
    { title: 'Average Order Value', value: '₱13.91', sub: 'Per Order' },
    { title: 'Items Sold', value: '23', sub: 'Total Items' },
  ];

  const tx = [
    { id: '#0001', item: 'Lechon Manok ×1', total: 320 },
    { id: '#0002', item: 'Liempo ×1', total: 350 },
    { id: '#0003', item: 'Lechon Manok ×1', total: 320 },
  ];

  // Y-axis guides (top, mid, base)
  const yTop = current.max;
  const yMid = Math.round(current.max / 2);

  return (
    <main className="main">
      <div className="topbar"><h1>Sales · Pullian Branch</h1></div>

      <div className="kpi-row">
        {kpis.map((k) => (
          <div key={k.title} className="kpi">
            <small>{k.title}</small>
            <div className="value">{k.value}</div>
            <div className="label">{k.sub}</div>
          </div>
        ))}
      </div>

      <div className="content">
        <div className="chart-card">
          <div className="chart-header">
            <h2>{current.title}</h2>
            <div className="chart-toggle">
              <button className={view === 'hour' ? 'active' : ''} onClick={() => setView('hour')}>Hour</button>
              <button className={view === 'day' ? 'active' : ''} onClick={() => setView('day')}>Day</button>
              <button className={view === 'week' ? 'active' : ''} onClick={() => setView('week')}>Week</button>
            </div>
          </div>

          <div className="chart-area">
            {/* Y-axis labels + guides */}
            <div className="chart-y">
              <span>₱{yTop}</span>
              <span>₱{yMid}</span>
              <span>0</span>
            </div>

            <div className="chart-plot">
              {/* horizontal guides */}
              <div className="guide top" />
              <div className="guide mid" />
              <div className="guide base" />

              {/* bars */}
              <div className="bars">
                {current.values.map((v, i) => {
                  const pct = (v / current.max) * 100;
                  return (
                    <div key={i} className="bar-col">
                      <div className="bar-space">
                        {v > 0 && (
                          <div className="bar-fill" style={{ height: `${pct}%` }}>
                            <span className="bar-tip">₱{v}</span>
                          </div>
                        )}
                      </div>
                      <div className="bar-label">{current.labels[i]}</div>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        </div>

        <div className="side-card">
          <h2 style={{ color: '#6B1A1A', marginBottom: 14 }}>Recent Transactions</h2>
          {tx.map((t) => (
            <div key={t.id} className="tx-row" style={{ cursor: 'pointer' }} onClick={() => setOpenTx(t)}>
              <span>{t.id}</span><span>{t.item}</span><span>₱{t.total.toFixed(2)}</span>
            </div>
          ))}
        </div>
      </div>

      {openTx && (
        <Modal onClose={() => setOpenTx(null)}>
          <div className="modal-icon">🧾</div>
          <div className="modal-title">Order {openTx.id}</div>
          <div className="modal-sub">Today, Aug 10 · Staff 1 · Pullian Branch</div>
          <div className="modal-row"><span>{openTx.item}</span><span>₱{openTx.total.toFixed(2)}</span></div>
          <div className="modal-row"><strong>Total</strong><strong>₱{openTx.total.toFixed(2)}</strong></div>
          <div className="modal-actions">
            <button className="secondary" onClick={() => setOpenTx(null)}>Close</button>
            <button className="primary" onClick={() => setOpenTx(null)}>Print Receipt</button>
          </div>
        </Modal>
      )}
    </main>
  );
}