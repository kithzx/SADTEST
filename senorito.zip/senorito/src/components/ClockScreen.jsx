import { useState } from 'react';
import Modal from './Modal';

export default function ClockScreen({ setScreen }) {
  const [confirmOpen, setConfirmOpen] = useState(false);
  const [clockedIn, setClockedIn] = useState(true);

  return (
    <main className="main">
      <div className="topbar"><h1>Clock In / Out</h1></div>

      <div className="clock-wrap">
        <div className="clock-card">
          <div className="clock-time">12:23 PM</div>
          <div className="clock-date">Monday, August 10</div>
          <div className="clock-badge">{clockedIn ? 'Clocked in since 6:00 AM' : 'Not clocked in'}</div>

          <div className="clock-stats">
            <div className="clock-stat"><div className="v">6h 23m</div><div className="l">On Shift</div></div>
            <div className="clock-stat"><div className="v">₱320.00</div><div className="l">Total Sales</div></div>
            <div className="clock-stat"><div className="v">23</div><div className="l">Orders</div></div>
          </div>

          {clockedIn ? (
            <button className="clock-btn" onClick={() => setConfirmOpen(true)}>Clock Out</button>
          ) : (
            <>
              <div className="pay-toggle" style={{ marginBottom: 12 }}>
                <button className="active">Morning</button>
                <button>Afternoon</button>
              </div>
              <button className="clock-btn" onClick={() => setClockedIn(true)}>Clock In</button>
              <div className="back-link">Select a shift, then clock in to start taking orders.</div>
            </>
          )}
        </div>
      </div>

      {confirmOpen && (
        <Modal onClose={() => setConfirmOpen(false)}>
          <div className="modal-icon warn">⏱</div>
          <div className="modal-title">End your shift?</div>
          <div className="modal-sub">Clocked in since 6:00 AM</div>
          <div className="modal-row"><span>On shift</span><span>6h 23m</span></div>
          <div className="modal-row"><span>Sales made</span><span>₱320.00</span></div>
          <div className="modal-row"><span>Orders</span><span>23</span></div>
          <div className="modal-actions">
            <button className="secondary" onClick={() => setConfirmOpen(false)}>Stay Clocked In</button>
            <button className="primary" onClick={() => { setConfirmOpen(false); setClockedIn(false); }}>Clock Out</button>
          </div>
        </Modal>
      )}
    </main>
  );
}