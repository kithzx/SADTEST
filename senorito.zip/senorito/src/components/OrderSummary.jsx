import { useState } from 'react';
import Modal from './Modal';

export default function OrderSummary({ cart, total, clearCart }) {
  const [method, setMethod] = useState('cash');
  const [received, setReceived] = useState('');
  const [success, setSuccess] = useState(false);
  const [confirmClear, setConfirmClear] = useState(false);

  const change = Math.max(0, Number(received || 0) - total);
  const insufficient = method === 'cash' && received !== '' && Number(received) < total;

  const canPay =
    cart.length > 0 &&
    (method === 'gcash' || (received !== '' && Number(received) >= total));

  const handlePay = () => {
    if (!canPay) return;
    setSuccess(true);
  };

  const finalize = () => {
    setSuccess(false);
    clearCart();
    setReceived('');
  };

  return (
    <aside className="summary">
      <h2>Order Summary</h2>
      <div className="summary-row"><span>Items</span><span>{cart.reduce((s, c) => s + c.qty, 0)}</span></div>
      <div className="summary-row"><strong>Total</strong><strong>₱{total.toFixed(2)}</strong></div>

      <div className="pay-toggle">
        <button className={method === 'cash' ? 'active' : ''} onClick={() => { setMethod('cash'); setReceived(''); }}>
          💵 Cash
        </button>
        <button className={method === 'gcash' ? 'active' : ''} onClick={() => setMethod('gcash')}>
          📱 GCash
        </button>
      </div>

      {method === 'cash' && (
        <>
          <input
            className={`amount-input ${insufficient ? 'error' : ''}`}
            placeholder="Amount Received"
            value={received}
            onChange={(e) => setReceived(e.target.value.replace(/[^0-9.]/g, ''))}
          />
          {insufficient && (
            <div className="insufficient">₱{Number(received).toFixed(2)} short of the ₱{total.toFixed(2)} total.</div>
          )}
        </>
      )}

      {method === 'gcash' && (
        <div className="gcash-box">
          <div className="gcash-qr">GCash QR</div>
          <div className="gcash-hint">Scan to pay ₱{total.toFixed(2)}</div>
          <input className="amount-input" placeholder="GCash reference no." />
        </div>
      )}

      <div className="summary-row"><span>Change</span><span>₱{change.toFixed(2)}</span></div>

      <button className="pay-btn" disabled={!canPay} onClick={handlePay}>
        Pay ₱{total.toFixed(2)}
      </button>
      <button className="clear-cart" onClick={() => cart.length > 0 && setConfirmClear(true)}>Clear Cart</button>

      {success && (
        <Modal onClose={() => setSuccess(false)}>
          <div className="modal-icon success">✓</div>
          <div className="modal-title">Payment successful</div>
          <div className="modal-sub">Order #0032 · Cash</div>
          <div className="modal-row"><span>Total</span><span>₱{total.toFixed(2)}</span></div>
          <div className="modal-row"><span>Amount received</span><span>₱{Number(received || total).toFixed(2)}</span></div>
          <div className="modal-row"><span>Change</span><span>₱{change.toFixed(2)}</span></div>
          <div className="modal-actions">
            <button className="secondary" onClick={finalize}>Print Receipt</button>
            <button className="primary" onClick={finalize}>New Order</button>
          </div>
        </Modal>
      )}

      {confirmClear && (
        <Modal onClose={() => setConfirmClear(false)}>
          <div className="modal-icon warn">!</div>
          <div className="modal-title">Clear this order?</div>
          <div className="modal-sub">All items in the current order will be removed. This can't be undone.</div>
          <div className="modal-actions">
            <button className="secondary" onClick={() => setConfirmClear(false)}>Keep Order</button>
            <button className="primary" onClick={() => { setConfirmClear(false); clearCart(); setReceived(''); }}>Clear Cart</button>
          </div>
        </Modal>
      )}
    </aside>
  );
}