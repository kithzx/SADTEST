export default function ProductGrid({ menuItems, addToCart }) {
  return (
    <div className="product-grid">
      {menuItems.map((item) => (
        <div key={item.id} className="product-card" onClick={() => addToCart(item)}>
          <div className="img">
            <img src={item.image || 'https://via.placeholder.com/120x120?text=Food'} alt={item.name} />
          </div>
          <h3>{item.name}</h3>
          <p>₱{item.price.toFixed(2)}</p>
        </div>
      ))}
    </div>
  );
}