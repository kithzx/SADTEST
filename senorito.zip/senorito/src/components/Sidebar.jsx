import { useEffect, useRef, useState } from 'react';
import logo from '../assets/senorito.png';
import Modal from './Modal';

export default function Sidebar({ screen, setScreen, onLogout }) {
  const [staffOpen, setStaffOpen] = useState(false);
  const [confirmLogout, setConfirmLogout] = useState(false);
  const staffRef = useRef(null);

  // close dropdown on outside click
  useEffect(() => {
    const handler = (e) => {
      if (staffRef.current && !staffRef.current.contains(e.target)) {
        setStaffOpen(false);
      }
    };
    document.addEventListener('mousedown', handler);
    return () => document.removeEventListener('mousedown', handler);
  }, []);

  const nav = [
    { key: 'order', label: 'Order' },
    { key: 'sales', label: 'Sales' },
    { key: 'inventory', label: 'Inventory' },
  ];

  return (
    <aside className="sidebar">
        <div className="logo">
            <img src={logo} alt="Señiorito" />
        </div>

      <nav>
        {nav.map((item) => (
          <div
            key={item.key}
            className={`nav-item ${screen === item.key ? 'active' : ''}`}
            onClick={() => setScreen(item.key)}
          >
            {item.label}
          </div>
        ))}
      </nav>

      <div className="branch-card">
        <small>Branch</small>
        <strong>Pullian Branch</strong>
      </div>

      <div ref={staffRef} style={{ position: 'relative' }}>
        {staffOpen && (
          <div className="staff-dropdown">
            <div className="head">
              <strong>Staff 1</strong>
              <span>Cashier | Pullian Branch</span>
            </div>
            <div onClick={() => { setScreen('settings'); setStaffOpen(false); }}>Settings</div>
            <div onClick={() => { setScreen('clock'); setStaffOpen(false); }}>Clock Out</div>
            <div className="danger" onClick={() => { setConfirmLogout(true); setStaffOpen(false); }}>Logout</div>
          </div>
        )}

        <div className="staff-card" onClick={() => setStaffOpen(!staffOpen)}>
          <div className="avatar">👤</div>
          <div>
            <strong>Staff 1</strong>
            <span>Cashier | Pullian Branch</span>
          </div>
        </div>
      </div>

      {confirmLogout && (
        <Modal onClose={() => setConfirmLogout(false)}>
          <div className="modal-icon">↪</div>
          <div className="modal-title">Log out?</div>
          <div className="modal-sub">
            You'll need to sign in again to use the POS. Your shift stays active until you clock out.
          </div>
          <div className="modal-actions">
            <button className="secondary" onClick={() => setConfirmLogout(false)}>Cancel</button>
            <button className="primary" onClick={() => { setConfirmLogout(false); onLogout(); }}>Log Out</button>
          </div>
        </Modal>
      )}
    </aside>
  );
}